<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
<base href="https://www.adeleyeayodeji.com/index.php" />
<meta charset="utf-8">
<meta name="description" content="Adeleye Ayodeji is a professional with a broad set of skills in software, web development, speaking among many other God-given talents. Equipped with so ...">
<meta name="keywords" content="Portfolio, Personal, Creatiev, adeleyeayodeji, Html Template, PHP, JavaScript">
<meta name="author" content="Adeleye Ayodeji | Web Developer">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:type" content="website" />
<meta property="og:title" content="Adeleye Ayodeji | Web Developer" />
<meta property="og:description" content="Adeleye Ayodeji is a professional with a broad set of skills in software, web development, speaking among many other God-given talents. Equipped with so ..." />
<meta property="og:url" content="https://www.adeleyeayodeji.com/" />
<meta property="og:image" content="https://www.adeleyeayodeji.com/img/adeleye_ayodeji_dp_new.PNG" />
<meta name="google-site-verification" content="fA9MCsV99k5sSM0pjLn4VwGS21o-O_IlorKV8KDITas" />

<title>Adeleye Ayodeji | Software Developer</title>

<link href="img/adeleye_ayodeji_dp_new.PNG" type="image/png" rel="icon">

<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/ionicons.css" rel="stylesheet" type="text/css">
<link href="css/mobiriseicons.css" rel="stylesheet" type="text/css">
<link href="css/owl.carousel.min.css" rel="stylesheet" type="text/css">
<link href="css/splitting.css" rel="stylesheet" type="text/css">
<link href="css/magnific-popup.css" rel="stylesheet" type="text/css">
<link href="css/main.css" rel="stylesheet" type="text/css">
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://unpkg.com/placeholder-loading/dist/css/placeholder-loading.min.css">
<script src="https://www.google.com/recaptcha/api.js?render=6LcwiVwaAAAAANP6Jok7LKD8oC1EgM1Zt1p8n2BT"></script>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-126555065-1"></script>
<script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-126555065-1');
        </script>

<script type="application/ld+json">
        {
            "@context": "http://schema.org",
            "@type": "LocalBusiness",
            "name": "Adeleye Ayodeji - Web Developer",
            "image": "https://adeleyeayodeji.com/img/adeleyeyayodeji_img1.jpeg",
            "telephone": "+234 703 4803 384",
            "email": "contact@adeleyeayodeji.com",
            "url": "https://adeleyeayodeji.com/",
            "address": {
                "@type": "PostalAddress",
                "streetAddress": "14 Shogbesan Ave, Alagbado, Moshalasi",
                "addressLocality": "Lagos",
                "addressCountry": "Nigeria",
                "postalCode": "100271"
            },
            "priceRange": "Not Fixed",
            "datePublished": "2019-07-27",
            "reviewRating": {
                "@type": "Rating",
                "ratingValue": "5.0",
                "bestRating": "5.0",
                "worstRating": "0"
            },
            "reviewBody": "He is a person you would want to work with. Such great a personality for a man with great talents."
        }
        </script>
<style>
        .float {
            position: fixed;
            width: 60px;
            height: 60px;
            bottom: 40px;
            left: 40px;
            background-color: #111111;
            color: #FFF;
            border-radius: 50px;
            border-left: 1px solid #302b2e;
            text-align: center;
            font-size: 30px;
            box-shadow: 3px 0px 1px 0px #df0e84;
            z-index: 100;
        }

        .my-float {
            margin-top: 16px;
        }
        </style>
</head>
<body id="top" data-spy="scroll" data-target="#menu_items">
<!--[if lte IE 9]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
    <![endif]-->

<div id="preloader">
<div class="scroll-static"></div>
</div>


<div class="landing_wrapper bg-img" data-src="img/shutterstock_1181290198-Converted-1920.jpg">

<header>
<div class="container">
<div class="row">
<div class="col-md-3 col-8">
<div class="logo">
<a href="index.php"><img src="img/logo-adeleye-w.png" alt="Adeleye Ayodeji" style="height: 50px;"></a>
</div>
</div>
<div class="col-md-9 col-4">
<ul id="menu_items" class="menu_items">
<li class="nav-item">
<a href="#top" class="active menu_item nav-link slide-horizontal" data-splitting>Home</a>
</li>
<li class="nav-item">
<a href="#about" class="menu_item nav-link slide-horizontal" data-splitting>About</a>
</li>
<li class="nav-item">
<a href="#service" class="menu_item nav-link slide-horizontal" data-splitting>Service</a>
</li>
<li class="nav-item">
<a href="#works" class="menu_item nav-link slide-horizontal" data-splitting>Works</a>
</li>
<li class="nav-item">
<a href="#github" class="menu_item nav-link slide-horizontal" data-splitting>GitHub</a>
</li>
<li class="nav-item">
<a href="#contact" class="menu_item nav-link slide-horizontal" data-splitting>Contact</a>
</li>
</ul>

<div class="nav-btn">
<span class="ion-android-menu"></span>
</div>
</div>
</div>
</div>
</header>


<div class="home_wrapper">

<div class="landing_content">
<div class="container">
<div class="row align-items-center">
<div class="col-12">
<h5 class="title-slide-in" data-splitting>Hi There, I'm</h5>
<h1 class="title-slide-in" data-splitting>Adeleye Ayodeji</h1>
<h4 class="title-slide-in" data-splitting>Software Developer &amp; Trainer</h4>
</div>
</div>
</div>
</div>

</div>

</div>

<div class="container">
<div class="row">
<div class="col">

<div id="about" class="about_wrapper">
<div class="about" itemscope="" itemtype="http://schema.org/Person">
<meta itemprop="gender" content="Male">
<meta itemprop="birthDate" content="Dec 20, 1997">
<meta itemprop="jobTitle" content="Software Developer">
<meta itemprop="email" content="contact@adeleyeayodeji.com">
<meta itemprop="url" content="https://adeleyeayodeji.com/">
<meta itemprop="name" content="Adeleye Ayodeji">
<meta itemprop="image" content="https://www.adeleyeayodeji.com/img/IMG_20200522_121756_834_2.jpg">
<div class="row justify-content-center align-items-center">
<div class="col-lg-4 col-md-5">

<div class="about_img">
<img class="about_img_1 top" src="img/IMG_20200522_121756_834_2.jpg" alt="">

</div>

</div>
<div class="col-lg-6 col-md-7">

<div class="about_info">
<h4>About me</h4>
<img class="zigzag" src="img/zigzag.svg" alt="">
<p class="about_desc">
<span>I am experienced in application and web development using PHP,
JavaScript, Dart(Flutter) and SQL Database services.</span>
<br>
I have a working experience with Model View Controller (MVC), and have been
involved in maintaining versions of source code using GitHub.I have also
designed and developed master pages, validation controls, CSS files using
technologies like AJAX Toolkit, JQuery, JavaScript, PHP, XML and HTML.
</p>
<p class="about_desc mt-4">
<span>When working on a new project,</span> I like to speak with my clients
so that I can have a clear understanding of their needs and vision of the
project. Thank you in advance for your time and consideration. I look
forward to working with you soon.
</p>

<ul class="social_links mt-4">
<li><a href="https://www.facebook.com/adeleyeayodeji.code" target="_blank" rel='noopener'><span class="ion-social-facebook"></span></a></li>
<li><a href="https://www.google.com/maps/place/Adeleye+Ayodeji/@6.6741407,3.265471,15z/data=!4m5!3m4!1s0x0:0x92f667b3cd4a9b05!8m2!3d6.6741407!4d3.265471" target="_blank" rel='noopener'><span class="ion-social-google"></span></a></li>
<li><a href="https://twitter.com/adeleyeayodeji_" target="_blank" rel='noopener'><span class="ion-social-twitter"></span></a></li>
<li><a href="https://www.instagram.com/adeleyeayodeji.code/" target="_blank" rel='noopener'><span class="ion-social-instagram-outline"></span></a></li>
<li><a href="https://www.linkedin.com/in/adeleye-ayodeji/" target="_blank" rel='noopener'><span class="ion-social-linkedin"></span></a></li>
</ul>

</div>

</div>
</div>
</div>
</div>


<div class="work_wrapper" style="background: linear-gradient(180deg, black, #dd02b263);}">
<div class="row justify-content-center">
<div class="col-lg-10">

<div class="text-center">
<h2 class="section_title">Featured Work</h2>
</div>
<div class="row works">

<div class="col-lg-6 col-md-6 col-sm-12 uiux">
<img src="img/logo-pde.webp" class="img-fluid rounded-circle" alt="" style="height: 120px;">
<h2>AQskill Mobile App</h2>
<p class="mt-3">AQskill is an online learning and teaching marketplace with over
10,000+
students</p>
<div class="row no-guter mt-4 mb-4">
<div class="col">
<a href="https://play.google.com/store/apps/details?id=com.aqskill.learn" target="_blank">
<img src="img/play.png" class="img-fluid" alt="">
</a>
</div>
<div class="col">
<a href="https://apps.apple.com/ng/app/aqskills/id1612672118" target="_blank">
<img src="img/app-store-ipod-touch-apple-apple.jpg" class="img-fluid" alt="" style="border-radius: 10px;">
</a>
</div>
</div>
</div>
<div class="col-lg-6 col-md-6 col-sm-12 uiux">
<div class="work_single_item">
<img class="img-fluid" src="img/AQskill.com.png" alt="AQskill.com">
</div>
</div>


</div>
</div>
</div>
</div>

<div id="service" class="services">
<div class="row justify-content-center">
<div class="col-lg-10">

<div class="text-center">
<h2 class="section_title">Services</h2>
</div>

<div class="service_items">
<div class="row">

<div class="col-lg-4 col-md-6 col-sm-6">
<div class="service_single_item">
<i class="mbri-sites"></i>
<h6 data-hover="Web Design">Web Design</h6>
<p>We help businesses unleash their full potentials through modern and
functional designs that make their competitors jealous.</p>
</div>
</div>


<div class="col-lg-4 col-md-6 col-sm-6">
<div class="service_single_item">
<i class="mbri-extension"></i>
<h6 data-hover="Web Development">Web Development</h6>
<p>We are highly-skilled in creating exceptional and effective website
from scratch using standards based markup code</p>
</div>
</div>


<div class="col-lg-4 col-md-6 col-sm-6">
<div class="service_single_item">
<i class="mbri-rocket"></i>
<h6 data-hover="Web Maintenance">Web Maintenance</h6>
<p>We help businesses focus on what’s truly important to them by
managing and growing their entire online presence.</p>
</div>
</div>
</div>
 </div>

</div>
</div>
</div>



<div id="works" class="work_wrapper">
<div class="row justify-content-center">
<div class="col-lg-10">

<div class="text-center">
<h2 class="section_title">Recent Works</h2>
</div>
<div class="row works">

<div class="col-lg-4 col-md-6 col-sm-6 web">
<div class="work_single_item">
<img class="img-fluid" src="img/whichbrideisnext.png" alt="Which bride is next">
<div class="work_info">
<h6 title="Which bride is next">Which bride is next?</h6>
<p>Online Reality Show</p>
<a class="link" href="https://whichbrideisnext.com/" target="_blank" rel='noopener'><span class="ion-android-expand"></span></a>
</div>
</div>
</div>

<div class="col-lg-4 col-md-6 col-sm-6 web">
<div class="work_single_item">
<img class="img-fluid" src="img/oshassociation.png" alt="">
<div class="work_info">
<h6 title="De Christie’s Ruby">OSHAssociation</h6>
<p>C R M</p>
<a class="link" href="https://oshassociation.org/" target="_blank" rel='noopener'><span class="ion-android-expand"></span></a>
</div>
</div>
</div>

<div class="col-lg-4 col-md-6 col-sm-6 web">
<div class="work_single_item">
<img class="img-fluid" src="img/Screenshot_2020-02-04 Maxfem Int'l Schools.jpg" alt="">
<div class="work_info">
<h6 title="Maxfem College">Maxfem College</h6>
<p>Result Management</p>
<a class="link" href="https://result.maxfemschools.com/find-result.php" target="_blank" rel='noopener'><span class="ion-android-expand"></span></a>
</div>
</div>
</div>

<div class="col-lg-4 col-md-6 col-sm-6 web">
<div class="work_single_item">
<img class="img-fluid" src="img/Screenshot_2020-02-04 BSTA Custom Tailor.png" alt="">
<div class="work_info">
<h6 title="BSTA Custom Tailor">BSTA Custom Tailor</h6>
<p>Custom Tailor</p>
<a class="link" href="https://bstatailors.net/" target="_blank" rel='noopener'><span class="ion-android-expand"></span></a>
</div>
</div>
</div>

<div class="col-lg-4 col-md-6 col-sm-6 branding">
<div class="work_single_item">
<img class="img-fluid" src="img/Screenshot_2020-02-04 Phronesis Foods .jpg" alt="">
<div class="work_info">
<h6 title="Phronesis Foods">Phronesis Foods</h6>
<p>Food processing and Packaging</p>
<a class="link" href="https://phronesisfoods.ng/" target="_blank" rel='noopener'><span class="ion-android-expand"></span></a>
</div>
</div>
</div>

<div class="col-lg-4 col-md-6 col-sm-6 uiux">
<div class="work_single_item">
<img class="img-fluid" src="img/Screenshot_2020-02-04 Home - Osho Ademola Joel.png" alt="">
<div class="work_info">
<h6 title="Osho Ademola Joel">Osho Ademola Joel</h6>
<p>Business Consulting & Digital Marketing</p>
<a class="link" href="https://www.oshoademolajoel.com/" target="_blank" rel='noopener'><span class="ion-android-expand"></span></a>
</div>
</div>
</div>


</div>
</div>
</div>
</div>


<div id="github" class="services">
<div class="row justify-content-center">
<div class="col-lg-10">

<div class="text-center">
<h2 class="section_title">Git Repository</h2>
</div>

<div class="service_items">
<div class="row" id="loops">

<div class="col-lg-4 col-md-6 col-sm-6">
<div class="service_single_item">
<i class="mbri-github"></i>
<a href="https://github.com/adeleyeayodeji/Ajax-Image-Upload-WIth-Progress-Bar" target="_blank" rel='noopener'>
<h6 style="font-size: 16px;" data-hover="Ajax-Image-Upload-WIth-Pr..">
Ajax-Image-Upload-WIth-Pr..</h6>
</a>
<p>Easily upload your images, files along with a prog..</p>
<a href="https://github.com/adeleyeayodeji/Ajax-Image-Upload-WIth-Progress-Bar/archive/master.zip" class="float-left" style="border: 1px solid #222;border: 1px solid #222;padding: 5px;margin-top: 20px;color: white;">Download
<span class="mbri-save text-bold" style="color: #ba0d84;margin-left: 8px;"></span></a>
<p style="border: 1px solid #222;color: #fff; margin-left: 150px;padding: 5px;text-align: center;margin-top: 20px;">
Hack</p>
</div>
</div>

<div class="col-lg-4 col-md-6 col-sm-6">
<div class="service_single_item"><i class="mbri-github"></i><a href="https://github.com/adeleyeayodeji/Basic-PHP-Ecommerce-" target="_blank" rel='noopener'>
<h6 style="font-size: 16px;" data-hover="Basic-PHP-Ecommerce-..">
Basic-PHP-Ecommerce-..</h6>
</a>
<p>Get started with ecommerce website development fro..</p><a href="https://github.com/adeleyeayodeji/Basic-PHP-Ecommerce-/archive/master.zip" class="float-left" style="border: 1px solid #222;border: 1px solid #222;padding: 5px;margin-top: 20px;color: white;">Download
<span class="mbri-save text-bold" style="color: #ba0d84;margin-left: 8px;"></span></a>
<p style="border: 1px solid #222;color: #fff; margin-left: 150px;padding: 5px;text-align: center;margin-top: 20px;">
JavaScript</p>
</div>
</div>
<div class="col-lg-4 col-md-6 col-sm-6">
<div class="service_single_item"><i class="mbri-github"></i><a href="https://github.com/adeleyeayodeji/codedeyo-githubb-repo" target="_blank" rel='noopener'>
<h6 style="font-size: 16px;" data-hover="codedeyo-githubb-repo..">
 codedeyo-githubb-repo..</h6>
</a>
<p>Showcase user repositories with a shortcode...</p><a href="https://github.com/adeleyeayodeji/codedeyo-githubb-repo/archive/master.zip" class="float-left" style="border: 1px solid #222;border: 1px solid #222;padding: 5px;margin-top: 20px;color: white;">Download
<span class="mbri-save text-bold" style="color: #ba0d84;margin-left: 8px;"></span></a>
<p style="border: 1px solid #222;color: #fff; margin-left: 150px;padding: 5px;text-align: center;margin-top: 20px;">
PHP</p>
</div>
</div>
</div>
<center>
<div class="col-lg-12" id="loadmore" style="display: none;">
<a class="button slide-vertical ajax-popup-link" data-splitting href="moregit.php">View All Gits</a>
</div>
</center>
</div>

</div>
</div>
</div>



<div id="contact" class="contact_wrapper">
<div class="text-center">
<h2 class="section_title">Drop a line</h2>
</div>
<div class="row justify-content-center">

<div class="col-lg-3 col-md-12">
<div class="contact_item">
<h5>Phone</h5>
<p><a href="tel:+2347034803384" target="_blank" rel='noopener'>+234 703 4803 384</a>
</p>
</div>
<div class="contact_item">
<h5>Email</h5>
<p><a href="mail:contact@adeleyeayodeji.com" target="_blank" rel='noopener'><span class="__cf_email__" data-cfemail="2a4945445e4b495e6a4b4e4f464f534f4b53454e4f404304494547">[email&#160;protected]</span></a></p>
</div>
</div>


<div class="col-lg-7 col-md-12">
<form id="contact-form" action="mail.php">
<div class="row">
<div class="col">
<p class="form-message"></p>
</div>
</div>
<div class="row">
<div class="col-md-5">

<input class="input_field required" id="name" type="text" name="name" placeholder="Name">

<input class="input_field required" id="email" type="email" name="email" placeholder="Email">
</div>
<div class="col-md-7">

<textarea class="input_field required" id="message" name="message" placeholder="Tell Me About Your Query."></textarea>
</div>
</div>
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 text-center">

<button class="button slide-vertical" type="submit" data-splitting>send
message</button>
</div>
</div>
</form>
</div>

</div>
</div>


<footer>
<a href="#top" class="go_top">
<i class="ion-ios-arrow-thin-up"></i>
</a>

<ul class="social_links">
<li><a href="https://www.facebook.com/adeleyeayodeji.code" target="_blank" rel='noopener'><span class="ion-social-facebook"></span></a></li>
<li><a href="https://www.google.com/maps/place/Adeleye+Ayodeji/@6.6741407,3.265471,15z/data=!4m5!3m4!1s0x0:0x92f667b3cd4a9b05!8m2!3d6.6741407!4d3.265471" target="_blank" rel='noopener'><span class="ion-social-google"></span></a></li>
<li><a href="https://twitter.com/adeleyeayodeji_" target="_blank" rel='noopener'><span class="ion-social-twitter"></span></a></li>
<li><a href="https://www.instagram.com/adeleyeayodeji.code/" target="_blank" rel='noopener'><span class="ion-social-instagram-outline"></span></a></li>
<li><a href="https://www.linkedin.com/in/adeleye-ayodeji-69a927158/" target="_blank" rel='noopener'><span class="ion-social-linkedin"></span></a></li>
</ul>
<p class="copyright">&copy; 2022 <span>Adeleye Ayodeji</span>. All Rights Reserved.</p>
<p>Created with <span><i class="fa fa-heart" style="color: #df0e84;"></i></span></p>
</footer>

</div>
</div>
</div>

<a href="https://api.whatsapp.com/send?phone=2347034803384&amp;text=Hello%20Adeleye%20Ayodeji,%20your%20service%20is%20requested." class="float" target="_blank" rel='noopener'>
<i class="fa fa-whatsapp my-float"></i>
</a>

<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="js/vendor/jquery-1.12.4.min.js"></script>
<script src="js/ajax-mail.js"></script>
<script src="js/api.js"></script>
<script src="js/plugins.js"></script>
<script src="js/main.js"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194" integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw==" data-cf-beacon='{"rayId":"75ec047f8b61b879","version":"2022.10.3","r":1,"token":"c770ff80b72e407689de8f8efa45d75b","si":100}' crossorigin="anonymous"></script>
</body>
</html>